module.exports = {
  HOST: 'cgpscstudy.in',
  USER: 'cgpscstu_pankaj',
  PASSWORD: 'eFni30~9',
  DB: 'cgpscstu_myproj'
 };